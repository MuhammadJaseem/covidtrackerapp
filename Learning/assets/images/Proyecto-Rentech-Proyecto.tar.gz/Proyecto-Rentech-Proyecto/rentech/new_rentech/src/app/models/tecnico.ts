export class Tecnico {
  dni?: string;
  nombre?: string;
  apellido?: string;
  correo?: string;
  telefono?: string;
  direccio?: string;
  salario?: string;
  iban?: string;
  contrasena?: string;
}
