export class AsignarAveria {
  constructor(
    public idEmpleado: string,
    public idAveria: string,
  ){}

}
