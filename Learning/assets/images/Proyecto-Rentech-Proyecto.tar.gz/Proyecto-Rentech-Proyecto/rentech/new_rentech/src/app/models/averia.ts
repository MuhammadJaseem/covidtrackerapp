export class Averia {
  nombre?: string;
  descripcion?: string;
  contacto?: string;
  urgencia?: string;
}
