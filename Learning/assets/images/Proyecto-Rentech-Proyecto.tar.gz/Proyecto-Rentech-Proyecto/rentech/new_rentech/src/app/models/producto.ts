export class Producto {
    nombre?: string;
    descripcion?: string;
    cantidad?: number;
    precio?: number;
    img?: string;
}


