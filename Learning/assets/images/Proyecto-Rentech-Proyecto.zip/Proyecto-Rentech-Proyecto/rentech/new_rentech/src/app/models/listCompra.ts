export class compra {
  nombre?: string;
  descripcion?: string;
  contacto?: string;
  urgencia?: string;
}
