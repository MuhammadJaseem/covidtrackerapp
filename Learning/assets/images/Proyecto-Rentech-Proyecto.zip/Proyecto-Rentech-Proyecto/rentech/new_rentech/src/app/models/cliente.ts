export class Cliente {
    correo?: string;
    contrasena?: string;
    nombre?: string;
    apellido?: string;
    telefono?: string;
    iban?: string;
    dni?: string;
    cp?: string;
    direccio?: string;
}


